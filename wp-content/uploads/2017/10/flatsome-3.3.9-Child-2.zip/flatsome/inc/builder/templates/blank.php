<?php

ux_builder_add_template( 'flatsome_blank', array(
  'name' => __( 'Blank', 'flatsome' ),
  'thumbnail' => flatsome_ux_builder_thumbnail( 'play' ),
  'content' => '',
) );
